## Installation
<p>
    1. Clone or extract the repository.<br>
    2. Create a database (database name: lavaui)<br>
    3. Import the sql file insde the database_sql_file folder<br>
    4. Open the project in integrated terminal and the run php -S localhost:8080<br>
    5. Enjoy
</p>
